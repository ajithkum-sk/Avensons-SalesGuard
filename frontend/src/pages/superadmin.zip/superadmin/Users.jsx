import React, { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { count } from "../../api.js";
import { adminApi } from "../../api/adminApi.js";
import RowMenu from "../../components/RowMenu.jsx";
import UserFormModal from "./UserFormModal.jsx";

const PAGE = 10;

export default function Users() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [offset, setOffset] = useState(0);
  const [formOpen, setFormOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);

  const load = () => {
    const params = { limit: PAGE, offset };
    if (search.trim()) params.search = search.trim();
    if (roleFilter !== "all") params.role = roleFilter;
    adminApi.users(params).then(setData).catch((e) => setError(e.message));
  };

  useEffect(() => {
    const timer = setTimeout(load, search ? 250 : 0);
    return () => clearTimeout(timer);
  }, [search, roleFilter, offset]);

  useEffect(() => setOffset(0), [search, roleFilter]);

  const toggleActive = async (u) => {
    const activating = !u.active;
    if (!window.confirm(`${activating ? "Reactivate" : "Deactivate"} ${u.name}'s account?`)) return;
    try {
      await adminApi.setUserActive(u.user_id, activating);
      toast.success(`${u.name} ${activating ? "reactivated" : "deactivated"}`);
      load();
    } catch (err) {
      toast.error(err.message || "Could not update this account");
    }
  };

  const resetPassword = async (u) => {
    if (!window.confirm(`Reset ${u.name}'s password? A new temporary password will be generated.`)) return;
    try {
      const res = await adminApi.resetUserPassword(u.user_id);
      toast.success(`New temporary password: ${res.temp_password}`, { duration: 10000 });
    } catch (err) {
      toast.error(err.message || "Could not reset password");
    }
  };

  return (
    <>
      <div className="topbar">
        <h1>User Management</h1>
        <span className="meta">Create and manage Manager and Salesperson accounts</span>
      </div>

      {error && <div className="error">{error}</div>}

      <div className="toolbar">
        <input type="search" placeholder="Search name or email" value={search}
               onChange={(e) => setSearch(e.target.value)} style={{ width: 240 }} />
        <select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)}>
          <option value="all">All roles</option>
          <option value="superadmin">Super Admin</option>
          <option value="manager">Manager</option>
          <option value="salesperson">Salesperson</option>
        </select>
        <span className="spacer" />
        <button className="primary" onClick={() => { setEditingUser(null); setFormOpen(true); }}>
          + Add User
        </button>
      </div>

      <div className="card" style={{ padding: 0 }}>
        <div className="table-scroll">
          <table>
            <thead>
              <tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th aria-label="Actions" /></tr>
            </thead>
            <tbody>
              {data?.rows.map((u) => (
                <tr key={u.user_id}>
                  <td>{u.name}</td>
                  <td className="note">{u.email}</td>
                  <td style={{ textTransform: "capitalize" }}>{u.role}</td>
                  <td>
                    <span className="pill" style={{ color: u.active ? "var(--ok)" : "var(--ink-soft)" }}>
                      {u.active ? "Active" : "Deactivated"}
                    </span>
                  </td>
                  <td className="delete-col">
                    <RowMenu
                      ariaLabel={`Actions for ${u.name}`}
                      items={[
                        { label: "Edit", onClick: () => { setEditingUser(u); setFormOpen(true); } },
                        { label: "Reset password", onClick: () => resetPassword(u) },
                        {
                          label: u.active ? "Deactivate" : "Reactivate",
                          danger: u.active,
                          onClick: () => toggleActive(u),
                        },
                      ]}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {data && data.rows.length === 0 && <div className="empty">No users match that search.</div>}
      </div>

      {data && data.total > PAGE && (
        <div className="toolbar" style={{ marginTop: 12 }}>
          <button className="ghost" disabled={offset === 0} onClick={() => setOffset(Math.max(0, offset - PAGE))}>Previous</button>
          <span className="note">{offset + 1}–{Math.min(offset + PAGE, data.total)} of {count(data.total)}</span>
          <button className="ghost" disabled={offset + PAGE >= data.total} onClick={() => setOffset(offset + PAGE)}>Next</button>
        </div>
      )}

      {formOpen && (
        <UserFormModal
          user={editingUser}
          onClose={() => setFormOpen(false)}
          onSaved={() => { setFormOpen(false); load(); }}
        />
      )}
    </>
  );
}