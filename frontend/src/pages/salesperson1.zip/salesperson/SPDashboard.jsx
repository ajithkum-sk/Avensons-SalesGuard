import React, { useEffect, useState } from "react";
import { count, money } from "../../api.js";
import { salespersonApi } from "../../api/salespersonApi.js";
import StatusPill from "./StatusPill.jsx";

const HIDDEN_RULE_CODES = ["R08_CHRONIC_DEFAULT_CUSTOMER"];
function PerformanceCard({ performance }) {
  if (!performance) return null;
  const { this_month_collected: thisMonth, last_month_collected: lastMonth, trend = [] } = performance;
  const change = lastMonth > 0 ? ((thisMonth - lastMonth) / lastMonth) * 100 : null;
  const max = Math.max(1, ...trend.map((t) => t.amount));
  

  return (
    <div className="card" style={{ marginBottom: 18 }}>
      <h2 style={{ marginBottom: 14 }}>My Performance</h2>
      <div className="grid k2" style={{ marginBottom: 16 }}>
        <div>
          <div className="label">This Month Collected</div>
          <div className="value">{money(thisMonth)}</div>
          {change != null && (
            <span className="pill" style={{ color: change >= 0 ? "var(--ok)" : "var(--danger)" }}>
              {change >= 0 ? "▲" : "▼"} {Math.abs(change).toFixed(0)}% vs last month
            </span>
          )}
        </div>
        <div>
          <div className="label">Last Month Collected</div>
          <div className="value">{money(lastMonth)}</div>
        </div>
      </div>

      {trend.length > 0 && (
        <svg viewBox={`0 0 ${trend.length * 28} 90`} width="100%" height="90" preserveAspectRatio="none">
          {trend.map((t, i) => {
            const h = (t.amount / max) * 60;
            return (
              <g key={`${t.label}-${i}`}>
                <rect x={i * 28 + 4} y={68 - h} width={16} height={Math.max(h, 1)} rx={3} fill="var(--accent)" />
                <text x={i * 28 + 12} y={82} fontSize="8" textAnchor="middle" fill="var(--ink-soft)">
                  {t.label}
                </text>
              </g>
            );
          })}
        </svg>
      )}
    </div>
  );
}

export default function SPDashboard({ onOpenShop, onViewAllShops, onOpenFlag }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    salespersonApi.dashboard().then(setData).catch((e) => setError(e.message));
  }, []);

  if (error) return <div className="error">{error}</div>;
  if (!data) return <div className="empty">Loading your dashboard…</div>;

  const { totals, by_rule = [], priority_shops = [], performance } = data;
  const visibleRules = by_rule.filter((r) => !HIDDEN_RULE_CODES.includes(r.rule_code));

  return (
    <>
      <div className="topbar">
        <h2>Your outstanding, at a glance</h2>
        {data.location && <span className="meta">Location — {data.location}</span>}
      </div>

      <div className="grid k4" style={{ marginBottom: 18 }}>
        <div className="card stat"><div className="label">Total Due</div><div className="value">{money(totals.total_due)}</div></div>
        <div className="card stat risk"><div className="label">Overdue</div><div className="value">{money(totals.overdue)}</div></div>
        <div className="card stat risk"><div className="label">High Risk Shops</div><div className="value">{count(totals.high_risk_shops)}</div></div>
        <div className="card stat"><div className="label">Good Outlets</div><div className="value">{count(totals.good_outlets)}</div></div>
      </div>

      <PerformanceCard performance={performance} />

      {visibleRules.length > 0 && (
        <div className="toolbar" style={{ marginBottom: 18, flexWrap: "wrap" }}>
          {visibleRules.map((r) => (
            <button key={r.rule_code} className="ghost" onClick={() => onOpenFlag(r.rule_code)}>
              {r.title} {r.hits != null && <span className="tally">({count(r.hits)})</span>}
            </button>
          ))}
        </div>
      )}

      <div className="card" style={{ padding: 0 }}>
        <div style={{ padding: "16px 16px 0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h2>Priority Shops</h2>
          <button className="linkbtn" onClick={onViewAllShops}>View All →</button>
        </div>
        <div className="table-scroll">
          <table>
            <thead><tr><th>Shop Name</th><th className="num">Outstanding</th><th className="num">Due Days</th><th>Status</th></tr></thead>
            <tbody>
              {priority_shops.map((s) => (
                <tr key={s.customer_code} className="row-click" tabIndex={0}
                    onClick={() => onOpenShop(s.customer_code)}
                    onKeyDown={(e) => e.key === "Enter" && onOpenShop(s.customer_code)}>
                  <td>{s.customer_name}</td>
                  <td className="num">{money(s.outstanding)}</td>
                  <td className="num">{s.due_days ?? "—"}</td>
                  <td><StatusPill status={s.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {priority_shops.length === 0 && <div className="empty">No priority shops right now — nice work.</div>}
      </div>
    </>
  );
}