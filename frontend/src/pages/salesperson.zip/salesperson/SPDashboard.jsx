import React, { useEffect, useState } from "react";
import { count, money } from "../../api.js";
import { salespersonApi } from "../../api/salespersonApi.js";
import StatusPill from "./StatusPill.jsx";

export default function SPDashboard({ onOpenShop, onViewAllShops, onOpenFlag }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    salespersonApi.dashboard().then(setData).catch((e) => setError(e.message));
  }, []);

  if (error) return <div className="error">{error}</div>;
  if (!data) return <div className="empty">Loading your dashboard…</div>;

  const { totals, by_rule = [], priority_shops = [] } = data;

  return (
    <>
      <div className="topbar">
        <h2>Your outstanding, at a glance</h2>
        {data.location && <span className="meta">Location — {data.location}</span>}
      </div>

      <div className="grid k4" style={{ marginBottom: 18 }}>
        <div className="card stat"><div className="label">Total Due</div><div className="value">{money(totals.total_due)}</div></div>
        <div className="card stat risk"><div className="label">Overdue</div><div className="value">{money(totals.overdue)}</div></div>
        <div className="card stat risk"><div className="label">High Risk Shops</div><div className="value">{count(totals.high_risk_shops)}</div></div>
        <div className="card stat"><div className="label">Good Outlets</div><div className="value">{count(totals.good_outlets)}</div></div>
      </div>

      {by_rule.length > 0 && (
        <div className="toolbar" style={{ marginBottom: 18, flexWrap: "wrap" }}>
          {by_rule.map((r) => (
            <button key={r.rule_code} className="ghost" onClick={() => onOpenFlag(r.rule_code)}>
              {r.title} {r.hits != null && <span className="tally">({count(r.hits)})</span>}
            </button>
          ))}
        </div>
      )}

      <div className="card" style={{ padding: 0 }}>
        <div style={{ padding: "16px 16px 0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h2>Priority Shops</h2>
          <button className="linkbtn" onClick={onViewAllShops}>View All →</button>
        </div>
        <div className="table-scroll">
          <table>
            <thead><tr><th>Shop Name</th><th className="num">Outstanding</th><th className="num">Due Days</th><th>Status</th></tr></thead>
            <tbody>
              {priority_shops.map((s) => (
                <tr key={s.customer_code} className="row-click" tabIndex={0}
                    onClick={() => onOpenShop(s.customer_code)}
                    onKeyDown={(e) => e.key === "Enter" && onOpenShop(s.customer_code)}>
                  <td>{s.customer_name}</td>
                  <td className="num">{money(s.outstanding)}</td>
                  <td className="num">{s.due_days ?? "—"}</td>
                  <td><StatusPill status={s.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {priority_shops.length === 0 && <div className="empty">No priority shops right now — nice work.</div>}
      </div>
    </>
  );
}